public class Car {
    private String brand;
    private int year;
    // milge in m
    private double milage;

    private UnitConverter.DistanceUnit distanceUnit;

    public Car(String brand, int year, UnitConverter.DistanceUnit distanceUnit) {
        this.brand = brand;
        this.year = year;
        this.distanceUnit = distanceUnit;
        this.milage = 0;
    }
    //velocity in m/s and time in s
    public void drive(double velocity, double time){
        milage += Math.abs(velocity) * time;
    }
    public void displayMilage(){
        if (distanceUnit.equals(UnitConverter.DistanceUnit.miles)) {
            System.out.println(UnitConverter.metersToMiles(milage));
        }else if (distanceUnit.equals(UnitConverter.DistanceUnit.kilometers)) {
            System.out.println(UnitConverter.meterToKilometers(milage));
        }else {
            System.out.println(milage);
        }
    }

    public double milageInKm() {
        return UnitConverter.meterToKilometers(milage);
    }

    public double milageInMiles() {
        return UnitConverter.metersToMiles(milage);
    }

}
