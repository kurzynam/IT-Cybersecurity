//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Car vehicle = new Car("Toyota", 2025, UnitConverter.DistanceUnit.kilometers);
        Car americanCar = new Car("Ford", 2025, UnitConverter.DistanceUnit.miles);
        vehicle.drive(UnitConverter.kmhToMs(100), UnitConverter.hoursToSecs(2));

        americanCar.drive(UnitConverter.mphToMs(100),UnitConverter.hoursToSecs(2));

        vehicle.displayMilage();
        americanCar.displayMilage();
    }
}