public class UnitConverter {
    public static double hoursToSecs(double hour){
        return hour * 60 * 60;
    }
    public static double secsToHours(double secs){
        return secs / 3600;
    }

    public static double kmhToMs(double kmh){
        return kmh / 3.6;
    }
    public static double mphToMs(double mph){
        return mph * 0.447;
    }
    public static double metersToMiles(double meters){
        return meters / 1610;
    }
    public static double milesToMeters(double miles){
        return miles * 1610;
    }
    public static double kilometersToMeters(double kilometers){
        return kilometers * 1000;
    }
    public static double kmToMiles(double km){
        return metersToMiles(kilometersToMeters(km));
    }

    public static double meterToKilometers(double meters){
        return meters/1000;
    }

    public enum DistanceUnit{
        meters,
        kilometers,
        miles
    }
}
