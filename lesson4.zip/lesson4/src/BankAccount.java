public class BankAccount {
    double balance;
    Person owner;


    BankAccount(String ownersName, int ownersAge, double balance) {
        this.owner = new Person(ownersName, ownersAge);
        this.balance = balance;
    }

    void depositMoney(double amount) {
        balance += amount;
    }
    void withdrawMoney(double amount) {
        balance -= amount;
    }
    double getBalance() {
        return balance;
    }
}
