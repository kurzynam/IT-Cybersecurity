public class Car {
    String brand;
    int year;
    Person owner;


    Car(String brand, int year) {
        this.brand = brand;
        this.year = year;
    }
    Car(String brand){
        this.brand = brand;
    }
    Car(){

    }
    void setOwner(String name, int age) {
        owner = new Person(name, age);
    }

    void setOwner(Person person){
        owner = person;
    }

    void showInfo(){
        System.out.println("This car is a " + brand + " and it is from " + year);
    }
}
