//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        BankAccount ba = new BankAccount("John", 20, 100);
        ba.withdrawMoney(50);
        ba.depositMoney(500);
        double finalBalance = ba.getBalance();
        System.out.println(finalBalance);
        ba.owner.introduce();

        Car carOne = new Car("Honda", 2015);


        carOne.setOwner(ba.owner);


        carOne.owner.introduce();
        ba.owner.introduce();
    }
}