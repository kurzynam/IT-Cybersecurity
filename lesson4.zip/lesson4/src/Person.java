public class Person {
    String name;
    int age;


    void introduce() {
        System.out.println("Hello, my name is " + this.name + " and I am " + this.age + " years old.");
    }


    Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    Person(int age) {
        this.age = age;
        this.name = "Unknown";
    }

    Person(){
        this.name = "Unknown";
        this.age = 0;
    }
}
